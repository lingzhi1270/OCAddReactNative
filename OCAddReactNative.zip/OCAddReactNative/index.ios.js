import React from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View
} from 'react-native';

import AppMain from './JSCode/AppMain'

class LZReactNativeDemo extends React.Component {
  render() {
   
    return (
<AppMain/>

    )}}

// 整体js模块的名称
AppRegistry.registerComponent('LZReactNativeDemo', () => AppMain);