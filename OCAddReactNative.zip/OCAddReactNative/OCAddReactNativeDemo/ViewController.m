//
//  ViewController.m
//  OCAddReactNativeDemo
//
//  Created by lingzhi on 2016/12/22.
//  Copyright © 2016年 lingzhi. All rights reserved.
//

#import "ViewController.h"
#import "RCTRootView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(100, 200, 140, 60);
    button.backgroundColor = [UIColor redColor];
    [button setTitle:@"进入RN界面" forState: UIControlStateNormal];
    [button addTarget:self action:@selector(gotoRNAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    
    
}

- (void)gotoRNAction{
    
    
    //此处直接使用  127.0.0.1取代localhost
    NSURL *jsCodeLocation =[NSURL URLWithString:@"http://127.0.0.1:8081/index.ios.bundle?platform=ios"];

    RCTRootView *rootView =
    [[RCTRootView alloc] initWithBundleURL : jsCodeLocation
                         moduleName        : @"LZReactNativeDemo"
                         initialProperties :
     @{
       @"scores" : @[
               @{
                   @"name" : @"年龄",
                   @"value": @"23"
                   },
               @{
                   @"name" : @"性别",
                   @"value": @"男"
                   },
               @{
                   @"name":@"QQ",
                   @"value":@"1534649018"
                   }
               ]
       }
                          launchOptions    : nil];
    UIViewController *vc = [[UIViewController alloc] init];
    vc.view = rootView;
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
